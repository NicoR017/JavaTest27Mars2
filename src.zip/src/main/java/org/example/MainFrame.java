import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainFrame extends JFrame {

    private JButton studentBtn, gradeBtn, subjectBtn, averageBtn, bestStudentBtn, subjectWorkBtn;

    public MainFrame() {
        // Create main panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Create buttons
        studentBtn = new JButton("Gérer les élèves");
        gradeBtn = new JButton("Gérer les notes");
        subjectBtn = new JButton("Gérer les matières");
        averageBtn = new JButton("Moyenne d'un élève");
        bestStudentBtn = new JButton("Meilleur élève");
        subjectWorkBtn = new JButton("Matière à travailler");

        // Add buttons to panel
        panel.add(studentBtn);
        panel.add(gradeBtn);
        panel.add(subjectBtn);
        panel.add(averageBtn);
        panel.add(bestStudentBtn);
        panel.add(subjectWorkBtn);

        // Add panel to frame
        this.add(panel);

        // Set frame properties
        this.setTitle("Gestion de l'éducation");
        this.setSize(400, 300);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set button actions
        studentBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Code pour gérer les élèves
            }
        });

        gradeBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Code pour gérer les notes
            }
        });

        subjectBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Code pour gérer les matières
            }
        });

        averageBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Code pour calculer la moyenne d'un élève
            }
        });

        bestStudentBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Code pour afficher le meilleur élève
            }
        });

        subjectWorkBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Code pour afficher les matières à travailler
            }
        });
    }

    public static void main(String[] args) {
        MainFrame frame = new MainFrame();
        frame.setVisible(true);
    }
}
