package org.example;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {



        Integer action = 0;
        while (action != 7) {
            Menu.MenuBase();
            action=Menu.ActionVerif(0);



            if (action == 1){ // élève
                Menu.MenuStudent();
                int actionStudent;
                actionStudent=Menu.ActionVerif(0);
                while (actionStudent!=0){
                    Menu.MenuStudent();
                    if(actionStudent==1){//création
                        Student student= Menu.CreateStudent();
                        StudentDAO studentDAO = new StudentDAOImpl();
                        String log="Menu.CreateStudent()";
                        Log.Save(log);
                        ///StudentDAO studentDAO = new StudentDAOImpl();
                        try {

                            if (studentDAO.addStudent(new Student(student.getFirstName(),student.getLastName(),student.getId()))) {
                                System.out.println("Elève enregistré avec succès");
                            } else {
                                System.out.println("Insertion failed !");
                            }
                        } catch (ClassNotFoundException | SQLException e) {
                            e.printStackTrace();
                        }
                        actionStudent=7;
                    } else if (actionStudent==2) { //modification
                        StudentDAO studentDAO = new StudentDAOImpl();
                        Student student= Menu.CreateStudent();
                        studentDAO.updateStudent(student);
                        actionStudent=0;
                        String log="studentDAO.updateStudent("+student+")";
                        Log.Save(log);
                    }else if (actionStudent==3) { //supprimer
                        StudentDAO studentDAO = new StudentDAOImpl();
                        studentDAO.getAllStudents();
                        String id;
                        Scanner scanner = new Scanner(System.in);
                        System.out.println("Entrer l'id de l'élève a supprimer");
                        id = scanner.nextLine();
                        studentDAO.deleteStudent(id);
                        String log="studentDAO.deleteStudent("+id+")";
                        Log.Save(log);
                        actionStudent=0;
                    }else if (actionStudent==4) { //sélectionner
                        StudentDAO studentDAO = new StudentDAOImpl();
                        studentDAO.getAllStudents();
                        String id;
                        Scanner scanner = new Scanner(System.in);
                        System.out.println("Entrer l'id de l'élève a afficher");
                        id = scanner.nextLine();
                        studentDAO.findStudentById(id);
                        String log="studentDAO.findStudentById("+id+")";
                        Log.Save(log);
                        actionStudent=0;
                    }else if (actionStudent==5) { //Liste
                        StudentDAO studentDAO = new StudentDAOImpl();
                        studentDAO.getAllStudents();
                        actionStudent=0;
                        String log="studentDAO.getAllStudents();";
                        Log.Save(log);
                    }
                }


            }
            else if (action==2) { //note
                Menu.MenuGrade();
                int actionNote;
                actionNote=Menu.ActionVerif(0);
                while (actionNote!=0){
                    Menu.MenuGrade();
                    if(actionNote==1){//création
                        Grade grade=Menu.CreateGrade();
                        GradeDAO gradeDAO= new GradeDAOImpl();
                        String log="Menu.CreateGrade()";
                        Log.Save(log);
                        try {

                            if (gradeDAO.addGrade(new Grade(grade.getId(),grade.getStudentId(),grade.getStudentId(),grade.getId()))) {
                                System.out.println("Note enregistré avec succès");
                            } else {
                                System.out.println("Insertion failed !");
                            }
                        } catch (ClassNotFoundException | SQLException e) {
                            e.printStackTrace();
                        }
                        actionNote=7;
                    } else if (actionNote==2) { //modification
                        GradeDAO gradeDAO = new GradeDAOImpl();
                        Grade grade=Menu.CreateGrade();
                        gradeDAO.updateGrade(grade);
                        actionNote=0;
                        String log="  gradeDAO.updateGrade("+grade+")";
                        Log.Save(log);
                    }else if (actionNote==3) { //supprimer
                        GradeDAO gradeDAO = new GradeDAOImpl();
                        gradeDAO.getAllGrade();
                        Integer id;
                        Scanner scanner = new Scanner(System.in);
                        System.out.println("Entrer l'id de l'élève a supprimer");
                        id = Menu.ActionVerif(Integer.valueOf(scanner.nextLine()));
                        gradeDAO.deleteGrade(id);
                        String log="gradeDAO.deleteGrade("+id+")";
                        Log.Save(log);
                        actionNote=0;
                    }else if (actionNote==4) { //sélectionner
                        GradeDAO gradeDAO = new GradeDAOImpl();
                        gradeDAO.getAllGrade();
                        int id;
                        Scanner scanner = new Scanner(System.in);
                        System.out.println("Entrer l'id de l'élève a afficher");
                        id = Menu.ActionVerif(Integer.valueOf(scanner.nextLine()));
                        gradeDAO.findGradeById(id);
                        String log=" gradeDAO.findGradeById("+id+")";
                        Log.Save(log);
                        actionNote=0;
                    }else if (actionNote==5) { //Liste
                        GradeDAO gradeDAODAO = new GradeDAOImpl();
                        String log=" gradeDAODAO.getAllGrade()";
                        Log.Save(log);
                        gradeDAODAO.getAllGrade();
                        actionNote=0;
                    }
                }

            }
            else if (action==3) {//sujet
                Menu.MenuSubject();
                int actionSubject;
                actionSubject=Menu.ActionVerif(0);
                while (actionSubject!=0){
                    Menu.MenuGrade();
                    if(actionSubject==1){//création
                        Subject subject=Menu.CreateSubject();
                        SubjectDAO subjectDAO= new SubjectDAOImpl();
                        String log="Menu.CreateSubject()";
                        Log.Save(log);
                        try {

                            if (subjectDAO.addSubject(new Subject(subject.getId(),subject.getName(),subject.getFactor()))) {
                                System.out.println("Sujet enregistré avec succès");
                            } else {
                                System.out.println("Insertion failed !");
                            }
                        } catch (ClassNotFoundException | SQLException e) {
                            e.printStackTrace();
                        }
                        actionSubject=7;
                    } else if (actionSubject==2) { //modification
                        Subject subject=Menu.CreateSubject();
                        SubjectDAO subjectDAO= new SubjectDAOImpl();
                        subjectDAO.updateSubject(subject);
                        actionSubject=0;
                        String log="subjectDAO.updateSubject("+subject+")";
                        Log.Save(log);
                    }else if (actionSubject==3) { //supprimer
                        SubjectDAO subjectDAO= new SubjectDAOImpl();
                        subjectDAO.getAllSubject();
                        String id;
                        Scanner scanner = new Scanner(System.in);
                        System.out.println("Entrer l'id du sujet a supprimer");
                        id = scanner.nextLine();
                        subjectDAO.deleteSubject(id);
                        String log="subjectDAO.deleteSubjec("+id+")";
                        Log.Save(log);
                        actionSubject=0;
                    }else if (actionSubject==4) { //sélectionner
                        SubjectDAO subjectDAO= new SubjectDAOImpl();
                        subjectDAO.getAllSubject();
                        String id;
                        Scanner scanner = new Scanner(System.in);
                        System.out.println("Entrer l'id du sujet a afficher");
                        id = scanner.nextLine();
                        subjectDAO.findSubjectById(id);
                        String log="subjectDAO.findSubjectById("+id+")";
                        Log.Save(log);
                        actionSubject=0;
                    }else if (actionSubject==5) { //Liste
                        SubjectDAO subjectDAO= new SubjectDAOImpl();
                        String log="subjectDAO.getAllSubject();";
                        Log.Save(log);
                        subjectDAO.getAllSubject();
                        actionSubject=0;
                    }
                }
            }else if (action==4){ //Moyenne Etudiant
                String id;
                StudentDAO studentDAO = new StudentDAOImpl();
                studentDAO.getAllStudents();
                Scanner scanner = new Scanner(System.in);
                System.out.println("Entrer l'id de l'élève");
                id = scanner.nextLine();
                String log="studentDAO.averageGradeStudent("+id+")";
                Log.Save(log);
                studentDAO.averageGradeStudent(id);
            }else if (action==5){ //Meilleur Etudiant
                StudentDAO studentDAO = new StudentDAOImpl();
                studentDAO.bestAverageGradeStudent();
                String log="studentDAO.bestAverageGradeStudent()";
                Log.Save(log);
            }else if (action==6){ //Matière a travailler
                StudentDAO studentDAO = new StudentDAOImpl();
                studentDAO.gradeToWorkStudent();
                String log="studentDAO.gradeToWorkStudent()";
                Log.Save(log);
            }


        }
    }


}