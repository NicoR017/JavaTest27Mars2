package org.example;

public class Subject {
    private String id;
    private String name;
    private Integer factor;


    public Subject(String id, String name, Integer factor){
        this.id=id;
        this.name=name;
        this.factor=factor;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getFactor() {
        return factor;
    }

    public void setFactor(Integer factor) {
        this.factor = factor;
    }
}
