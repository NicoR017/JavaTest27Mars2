package org.example;

import java.sql.SQLException;
import java.util.List;

public interface SubjectDAO {
    Boolean addSubject(Subject subject) throws ClassNotFoundException, SQLException;

    void deleteSubject(String id) throws ClassNotFoundException, SQLException;



    List<Subject> getAllSubject() throws ClassNotFoundException, SQLException;


    void updateSubject(Subject subject) throws ClassNotFoundException, SQLException;

    Subject findSubjectById(String id) throws ClassNotFoundException, SQLException;

}
