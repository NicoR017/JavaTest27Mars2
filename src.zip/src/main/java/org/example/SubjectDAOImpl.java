package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SubjectDAOImpl implements SubjectDAO{

    @Override
    public Boolean addSubject(Subject subject) throws ClassNotFoundException, SQLException {
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        String insertionQuery = "INSERT INTO subject (id, name, factor) VALUES (?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertionQuery);
        preparedStatement.setString(1, subject.getId());
        preparedStatement.setString(2, subject.getName());
        preparedStatement.setInt(3, subject.getFactor());
        int rowsAffected = preparedStatement.executeUpdate();
        return rowsAffected > 0;
    }

    @Override
    public void deleteSubject(String id) throws ClassNotFoundException, SQLException {
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        String insertionQuery = "DELETE FROM subject WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(insertionQuery);
        preparedStatement.setString(1, id);

        int rowsAffected = preparedStatement.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Le sujet a été supprimé avec succès.");
        } else {
            System.out.println("Aucun sujet trouvé avec cet ID.");
        }
        preparedStatement.close();
        connection.close();
    }

    @Override
    public List<Subject> getAllSubject() throws ClassNotFoundException, SQLException {
        ArrayList<Subject> subjects = new ArrayList<>();
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from subject");
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            String id = resultSet.getString("id");
            String name = resultSet.getString("name");
            int factor = resultSet.getInt("factor");
            System.out.println("id: " + id);
            subjects.add(new Subject(id, name, factor));
        }
        resultSet.close();
        preparedStatement.close();
        connection.close();
        return subjects;
    }

    @Override
    public void updateSubject(Subject subject) throws ClassNotFoundException, SQLException {
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        String deletionQuery = "UPDATE subject SET factor=? AND name=? AND  WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(deletionQuery);
        preparedStatement.setInt(1, subject.getFactor());
        preparedStatement.setString(2,  subject.getName());
        preparedStatement.setString(3,  subject.getId());
        int rowsAffected = preparedStatement.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("La note a été modifier avec succès.");
        } else {
            System.out.println("Aucune note trouvé avec cet ID.");
        }
        preparedStatement.close();
        connection.close();
    }

    @Override
    public Subject findSubjectById(String id) throws ClassNotFoundException, SQLException {
        Subject subject=null;
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from subject where id=?");
        preparedStatement.setString(1, id);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            String name = resultSet.getString("name");
            int factor = resultSet.getInt("factor");
            System.out.println("id: " + id);
            System.out.println("firstName: " + name);
            System.out.println("lastName: " + factor);
            subject=new Subject(id,name, factor);

        }
        resultSet.close();
        preparedStatement.close();
        connection.close();
        return subject;
    }
}
