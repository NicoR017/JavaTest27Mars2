package org.example;

import java.util.Scanner;

public class Menu {

    public static void MenuBase(){
        System.out.println("Bienvenue");
        System.out.println("Dans votre gestionnnaire de tâches");
        System.out.println("|-------------------------------------------------------|");
        System.out.println("|  0. Quitter                                           |");
        System.out.println("|  1. Elève                                             |");
        System.out.println("|  2. Note                                              |");
        System.out.println("|  3. Sujet                                             |");
        System.out.println("|  4. Moyenne d'un élève                                |");
        System.out.println("|  5. Meilleur élève                                    |");
        System.out.println("|  6. Matière a traviller                               |");
        System.out.println("|-------------------------------------------------------|");
    }
    public static int ActionVerif(Integer action){

        boolean continuer = true;
        while (continuer == true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Entrer une option: ");
            try {
                action = Integer.parseInt(scanner.nextLine());
                continuer = false;

            } catch (NumberFormatException e) {
                System.out.println("Rentrer un nombre et non une chaine " + e.getMessage());
                continuer = true;
            }
        }
        return action;
    }
    public static Student CreateStudent(){
        String id;
        String firtName;
        String lastName;

        System.out.println("|--------------------------|");
        System.out.println("|Création d'un nouvel élève|");
        System.out.println("|--------------------------|");
        System.out.println(" ");
        System.out.println(" ");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Id de l'élève:");
        id = scanner.nextLine();
        System.out.println("Prénom de l'élève:");
        firtName = scanner.nextLine();
        System.out.println("Nom de l'élève:");
        lastName = scanner.nextLine();
        return new Student(firtName,lastName,id);
    }
    public static Grade CreateGrade(){
        String idStudent;
        String idSubject;
        int grade;

        System.out.println("|----------------------------|");
        System.out.println("|Création d'une nouvelle note|");
        System.out.println("|----------------------------|");
        System.out.println(" ");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Id de l'élève:");
        idStudent = scanner.nextLine();
        System.out.println("Sujet:");
        idSubject = scanner.nextLine();
        System.out.println("Note:");
        grade = ActionVerif(Integer.valueOf(scanner.nextLine()));
        return new Grade(1,idStudent,idSubject,grade);
    }
    public static Subject CreateSubject(){
        String nom;
        String idSubject;
        int factor;

        System.out.println("|-----------------------------|");
        System.out.println("| Création d'un nouveau sujet |");
        System.out.println("|-----------------------------|");
        System.out.println(" ");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Id du Sujet:");
        idSubject = scanner.nextLine();
        System.out.println("Nom:");
        nom = scanner.nextLine();
        System.out.println("Coef:");
        factor = ActionVerif(Integer.valueOf(scanner.nextLine()));
        return new Subject(idSubject,nom,factor);
    }
    public static void MenuStudent(){
        System.out.println("Elèves");
        System.out.println("|-------------------------------------------------------|");
        System.out.println("|  0. Quitter                                           |");
        System.out.println("|  1. Ajouter un Elève                                  |");
        System.out.println("|  2. Modifier une Elève                                |");
        System.out.println("|  3. Supprimer un Elève                                |");
        System.out.println("|  4. Sélectionner un Elève                             |");
        System.out.println("|  5. Liste Elève                                       |");
        System.out.println("|-------------------------------------------------------|");
    }
    public static void MenuGrade(){
        System.out.println("Note");
        System.out.println("|-------------------------------------------------------|");
        System.out.println("|  0. Quitter                                           |");
        System.out.println("|  1. Ajouter un Note                                   |");
        System.out.println("|  2. Modifier une Note                                 |");
        System.out.println("|  3. Supprimer un Note                                 |");
        System.out.println("|  4. Sélectionner un Note                              |");
        System.out.println("|  5. Liste Note                                        |");
        System.out.println("|-------------------------------------------------------|");
    }
    public static void MenuSubject(){
        System.out.println("Sujets");
        System.out.println("|-------------------------------------------------------|");
        System.out.println("|  0. Quitter                                           |");
        System.out.println("|  1. Ajouter un Sujets                                 |");
        System.out.println("|  2. Modifier une Sujets                               |");
        System.out.println("|  3. Supprimer un Sujets                               |");
        System.out.println("|  4. Sélectionner un Sujets                            |");
        System.out.println("|  5. Liste Sujets                                      |");
        System.out.println("|-------------------------------------------------------|");
    }
}
