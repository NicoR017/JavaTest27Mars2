package org.example;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
public class StudentDAOImpl implements StudentDAO {

    @Override
    public Boolean addStudent(Student student) throws ClassNotFoundException, SQLException {
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        String insertionQuery = "INSERT INTO student (id, firstName, lastName) VALUES (?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertionQuery);
        preparedStatement.setString(1, student.getId());
        preparedStatement.setString(2, student.getFirstName());
        preparedStatement.setString(3, student.getLastName());
        int rowsAffected = preparedStatement.executeUpdate();
        return rowsAffected > 0;
    }

    @Override
    public void deleteStudent(String id) throws ClassNotFoundException, SQLException {
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        String insertionQuery = "DELETE FROM student WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(insertionQuery);
        preparedStatement.setString(1, id);

        int rowsAffected = preparedStatement.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("L'étudiant a été supprimé avec succès.");
        } else {
            System.out.println("Aucun étudiant trouvé avec cet ID.");
        }
        preparedStatement.close();
        connection.close();
    }

    @Override
    public List<Student> getAllStudents() throws ClassNotFoundException, SQLException {
        ArrayList<Student> students = new ArrayList<>();
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from student");
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            String id = resultSet.getString("id");
            String firstName = resultSet.getString("firstName");
            String lastName = resultSet.getString("lastName");
            System.out.println("id: " + id);
            students.add(new Student(firstName, lastName, id));
        }
        resultSet.close();
        preparedStatement.close();
        connection.close();
        return students;
    }

    @Override
    public void updateStudent(Student student) throws ClassNotFoundException, SQLException {
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        String updateQuery = "UPDATE student SET firstName = ?, lastName = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
        preparedStatement.setString(1, student.getFirstName());
        preparedStatement.setString(2, student.getLastName());
        preparedStatement.setString(3, student.getId());
        int rowsAffected = preparedStatement.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("L'étudiant a été modifié avec succès.");
        } else {
            System.out.println("Aucun étudiant trouvé avec cet ID.");
        }
        preparedStatement.close();
        connection.close();
    }

    @Override
    public Student findStudentById(String id) throws ClassNotFoundException, SQLException {

        String firstName = null;
        String lastName = null;
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from student where id=?");
        preparedStatement.setString(1, id);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            id = resultSet.getString("id");
            firstName = resultSet.getString("firstName");
            lastName = resultSet.getString("lastName");
            System.out.println("id: " + id);
            System.out.println("firstName: " + firstName);
            System.out.println("lastName: " + lastName);


        }
        Student student = new Student(firstName, lastName, id);
        resultSet.close();
        preparedStatement.close();
        connection.close();
        return student;
    }

    @Override
    public void averageGradeStudent(String id) throws ClassNotFoundException, SQLException {

        ArrayList<Grade> grades = new ArrayList<>();
        Integer average = 0;
        Integer i = 1;
        String firstName = null;
        String lastName = null;

        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from grade WHERE student_id=?");
        preparedStatement.setString(1, id);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            average = +resultSet.getInt("grade");
            i = +1;
        }
        average = average / i;
        PreparedStatement preparedStatement1 = connection.prepareStatement("SELECT * from student where id=?");
        preparedStatement1.setString(1, id);
        ResultSet resultSet1 = preparedStatement1.executeQuery();
        while (resultSet1.next()) {
            firstName = resultSet1.getString("firstName");
            lastName = resultSet1.getString("lastName");
            System.out.println("L'etudiant " + firstName + " " + lastName + " a une moyenne de " + average);


        }


    }

    public void bestAverageGradeStudent() throws ClassNotFoundException, SQLException {
        String id = null;
        Integer average = 0;
        Integer averageMax = 0;
        Integer i = 0;
        String firstName = null;
        String lastName = null;
        String firstNameMax = null;
        String lastNameMax = null;
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();

        PreparedStatement preparedStatementIdStudent = connection.prepareStatement("SELECT * from student");
        ResultSet resultSetIdStudent = preparedStatementIdStudent.executeQuery();

        while (resultSetIdStudent.next()) {
            firstName = resultSetIdStudent.getString("firstName");
            lastName = resultSetIdStudent.getString("lastName");
            id = resultSetIdStudent.getString("id");
            PreparedStatement preparedStatementGrade = connection.prepareStatement("SELECT * from grade WHERE student_id=?");
            preparedStatementGrade.setString(1, id);
            ResultSet resultSetGrade = preparedStatementGrade.executeQuery();
            i = 0;
            average = 0;
            while (resultSetGrade.next()) {
                PreparedStatement preparedStatementFactor = connection.prepareStatement("SELECT * from subject WHERE id=?");
                preparedStatementFactor.setString(1, resultSetGrade.getString("subject_id"));
                ResultSet resultSetFactor = preparedStatementFactor.executeQuery();
                if (resultSetFactor.next()) {
                    average += resultSetGrade.getInt("grade") * resultSetFactor.getInt("factor");
                    i += resultSetFactor.getInt("factor");
                }
            }
            if (i != 0) {
                average = average / i;
            }
            if (average > averageMax) {
                averageMax = average;
                firstNameMax = firstName;
                lastNameMax = lastName;
            }
        }
        if (firstNameMax != null && lastNameMax != null) {
            System.out.println("L'etudiant qui a la meilleur moyenne est " + firstNameMax + " " + lastNameMax + " avec une moyenne de " + averageMax);
        } else {
            System.out.println("Aucun étudiant trouvé.");
        }

    }

    public void gradeToWorkStudent() throws ClassNotFoundException, SQLException {
        String id = null;
        Double average = 0.0;
        Double averageMin = 15.0;
        Integer i = 0;
        String firstName = null;
        String lastName = null;
        String subjectMin = null;

        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();

        PreparedStatement preparedStatementIdStudent = connection.prepareStatement("SELECT * from student");
        ResultSet resultSetIdStudent = preparedStatementIdStudent.executeQuery();

        while (resultSetIdStudent.next()) {
            firstName = resultSetIdStudent.getString("firstName");
            lastName = resultSetIdStudent.getString("lastName");
            id = resultSetIdStudent.getString("id");
            PreparedStatement preparedStatementFactor = connection.prepareStatement("SELECT * from subject");
            ResultSet resultSetFactor = preparedStatementFactor.executeQuery();
            while (resultSetFactor.next()) {
                PreparedStatement preparedStatementGrade = connection.prepareStatement("SELECT * from grade WHERE student_id=? AND subject_id=?");
                preparedStatementGrade.setString(1, id);
                preparedStatementGrade.setString(2, resultSetFactor.getString("id"));
                ResultSet resultSetGrade = preparedStatementGrade.executeQuery();
                i = 0;
                average = 0.0;
                while (resultSetGrade.next()) {
                    average += resultSetGrade.getInt("grade") * resultSetFactor.getInt("factor");
                    i += resultSetFactor.getInt("factor");
                }
                if (i != 0) {
                    average = average / i;
                }
                if (average < averageMin) {
                    averageMin = average;
                    subjectMin = resultSetFactor.getString("name");
                }
            }
            if (averageMin < 15) {
                System.out.println(firstName + " " + lastName + " doit absolument travailler la matière " + subjectMin);
            }
        }

    }
}
