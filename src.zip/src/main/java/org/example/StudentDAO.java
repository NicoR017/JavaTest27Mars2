package org.example;

import java.sql.SQLException;
import java.util.List;

public interface  StudentDAO {
    Boolean addStudent(Student student) throws ClassNotFoundException, SQLException;

    void deleteStudent(String id) throws ClassNotFoundException, SQLException;



    List<Student> getAllStudents() throws ClassNotFoundException, SQLException;


    void updateStudent(Student student) throws ClassNotFoundException, SQLException;

    Student findStudentById(String id) throws ClassNotFoundException, SQLException;

    void averageGradeStudent(String id) throws ClassNotFoundException, SQLException;
    void bestAverageGradeStudent() throws ClassNotFoundException, SQLException;
    void gradeToWorkStudent() throws ClassNotFoundException, SQLException;
}
