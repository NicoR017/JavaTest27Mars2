package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GradeDAOImpl implements GradeDAO {

    @Override
    public Boolean addGrade(Grade grade) throws ClassNotFoundException, SQLException {
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        String insertionQuery = "INSERT INTO grade (studentId, subjectId, grade) VALUES (?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(insertionQuery);
        preparedStatement.setString(1, grade.getStudentId());
        preparedStatement.setString(2, grade.getSubjectId());
        preparedStatement.setInt(3, grade.getGrade());
        int rowsAffected = preparedStatement.executeUpdate();
        return rowsAffected > 0;
    }

    @Override
    public void deleteGrade(int id) throws ClassNotFoundException, SQLException {
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        String insertionQuery = "DELETE FROM grade WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(insertionQuery);
        preparedStatement.setInt(1, id);

        int rowsAffected = preparedStatement.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("La note a été supprimé avec succès.");
        } else {
            System.out.println("Aucun note trouvé avec cet ID.");
        }
        preparedStatement.close();
        connection.close();
    }

    @Override
    public List<Grade> getAllGrade() throws ClassNotFoundException, SQLException {
        ArrayList<Grade> grades = new ArrayList<>();
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from grade");
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            String studenId = resultSet.getString("student_id");
            String subjectId = resultSet.getString("subject_id");
            int grade = resultSet.getInt("grade");
            int id = resultSet.getInt("id");
            System.out.println("id: " + id);
            grades.add(new Grade(id, studenId, subjectId,grade));
        }
        resultSet.close();
        preparedStatement.close();
        connection.close();
        return grades;
    }

    @Override
    public void updateGrade(Grade grade) throws ClassNotFoundException, SQLException {
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        String deletionQuery = "UPDATE grade SET student_id=? AND subject_id=? AND grade=? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(deletionQuery);
        preparedStatement.setString(1, grade.getStudentId());
        preparedStatement.setString(2, grade.getStudentId());
        preparedStatement.setInt(3, grade.getGrade());
        preparedStatement.setInt(3, grade.getId());
        int rowsAffected = preparedStatement.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("La note a été modifier avec succès.");
        } else {
            System.out.println("Aucune note trouvé avec cet ID.");
        }
        preparedStatement.close();
        connection.close();
    }

    @Override
    public Grade findGradeById(int id) throws ClassNotFoundException, SQLException {
        Grade grade=null;
        StudentDBconfig studentDBConfig = new StudentDBconfig();
        Connection connection = studentDBConfig.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * from grade where id=?");
        preparedStatement.setInt(1,  id);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            int grades = resultSet.getInt("grade");
            String studentId = resultSet.getString("student_id");
            String subjectId = resultSet.getString("subject_id");
            System.out.println("id: " + id);
            System.out.println("student id: " + studentId);
            System.out.println("subject Id: " + subjectId);
            System.out.println("grades: " + grades);
            grade=new Grade(id, studentId, subjectId,grades);

        }
        resultSet.close();
        preparedStatement.close();
        connection.close();
        return grade;
    }
}
