package org.example;

import java.sql.SQLException;
import java.util.List;

public interface GradeDAO {

    Boolean addGrade(Grade grade) throws ClassNotFoundException, SQLException;

    void deleteGrade(int id) throws ClassNotFoundException, SQLException;



    List<Grade> getAllGrade() throws ClassNotFoundException, SQLException;


    void updateGrade(Grade grade) throws ClassNotFoundException, SQLException;

    Grade findGradeById(int id)throws ClassNotFoundException, SQLException;
}
